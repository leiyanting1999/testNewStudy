$('.carousel').carousel({
  interval: 1000
})

$(".xlc1").hover(function () {
  $('.xl-1').css({'display':'block'})
},function () {
  $('.xl-1').css({'display':'none'})
})

$(".xlc2").hover(function () {
  $('.xl-2').css({'display':'block'})
},function () {
  $('.xl-2').css({'display':'none'})
})

$(".xlc3").hover(function () {
  $('.xl-3').css({'display':'block'})
},function () {
  $('.xl-3').css({'display':'none'})
})

$(".xlc4").hover(function () {
  $('.xl-4').css({'display':'block'})
},function () {
  $('.xl-4').css({'display':'none'})
})